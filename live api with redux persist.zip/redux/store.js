import { configureStore, combineReducers } from '@reduxjs/toolkit';
import counterReducer from './counterSlice';
import userReducer from './UserSlice';
import { persistStore, persistReducer } from 'redux-persist';
import AsyncStorage from '@react-native-async-storage/async-storage'; // For React Native

// ✅ Define persist config
const persistConfig = {
  key: 'root',
  storage: AsyncStorage, // Use AsyncStorage for React Native
  whitelist: ['user'], // Only persist 'user', not 'counter' (optional)
};

// ✅ Combine reducers
const rootReducer = combineReducers({
  counter: counterReducer,
  user: userReducer,
});

// ✅ Wrap rootReducer with persistReducer
const persistedReducer = persistReducer(persistConfig, rootReducer);

// ✅ Configure store
const store = configureStore({
  reducer: persistedReducer,
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: false, // Ignore non-serializable warning
    }),
});

// ✅ Persist store
const persistor = persistStore(store);

export { store, persistor };
