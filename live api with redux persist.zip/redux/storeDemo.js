// import { configureStore } from '@reduxjs/toolkit';
// import { persistStore, persistReducer } from 'redux-persist';
// import AsyncStorage from '@react-native-async-storage/async-storage';
// import { combineReducers } from 'redux';
// import counterReducer from './counterSlice';

// // Persist configuration
// const persistConfig = {
//   key: 'root',
//   storage: AsyncStorage,
// };

// // Combine reducers
// const rootReducer = combineReducers({
//   counter: persistReducer(persistConfig, counterReducer),
// });

// // Create store
// const store = configureStore({
//   reducer: rootReducer,
// });

// const persistor = persistStore(store);

// export { store, persistor };
