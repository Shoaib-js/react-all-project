// CounterScreen.js
import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';
import { useSelector, useDispatch } from 'react-redux';
import { increase, decrease, reset } from './counterSlice';
import { setName, setEmail,  toggleLogin, clearUser } from './UserSlice';


const CounterScreen = () => {
  const count = useSelector((state) => state.counter?.value || 0);
  const dispatch = useDispatch();

  return (
    <View style={styles.container}>
      <Text style={styles.counterText}>Counter: {count}</Text>
      <View style={styles.buttonContainer}>
        <Button title="Increase" onPress={() => dispatch(increase())} />
        <Button title="Decrease" onPress={() => dispatch(decrease())} />
        <Button title="Reset" onPress={() => dispatch(reset())} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
  },
  counterText: {
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  buttonContainer: {
    width: '80%',
    gap: 10, // Adds space between buttons
  },
});

export default CounterScreen;

